import{d$ as n}from"./main-CFePQ27m.js";const c={dateStyle:"long",timeStyle:"short"};function l(){const{whoAmI:t}=n(),o=t.getLocale();return function(e,a){return e.toLocaleString(o,a)}}export{c as F,l as u};
//# sourceMappingURL=useFormatDate-IMrnpsMK.js.map
