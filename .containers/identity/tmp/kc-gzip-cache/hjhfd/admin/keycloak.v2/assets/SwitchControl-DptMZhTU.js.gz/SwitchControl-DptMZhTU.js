import{jsx as a}from"react/jsx-runtime";import{a as r,W as n}from"./main-CFePQ27m.js";const l=t=>{const{t:o}=r();return a(n,{...t,labelOn:o("on"),labelOff:o("off")})};export{l as D};
//# sourceMappingURL=SwitchControl-DptMZhTU.js.map
