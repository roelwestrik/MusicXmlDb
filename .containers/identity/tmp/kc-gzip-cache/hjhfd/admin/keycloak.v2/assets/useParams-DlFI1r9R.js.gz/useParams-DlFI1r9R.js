import{c as s}from"./main-CFePQ27m.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-DlFI1r9R.js.map
