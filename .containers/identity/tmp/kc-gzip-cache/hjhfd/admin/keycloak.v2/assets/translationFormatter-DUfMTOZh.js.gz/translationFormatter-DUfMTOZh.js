import{db as o}from"./main-CFePQ27m.js";const n=r=>t=>t&&o(r,t)||"—";export{n as t};
//# sourceMappingURL=translationFormatter-DUfMTOZh.js.map
