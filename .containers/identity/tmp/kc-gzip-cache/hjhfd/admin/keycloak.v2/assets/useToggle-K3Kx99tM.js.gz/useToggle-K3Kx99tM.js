import{useState as o,useCallback as s}from"react";function r(t=!1){const[u,e]=o(t),a=s(()=>e(l=>!l),[]);return[u,a,e]}export{r as u};
//# sourceMappingURL=useToggle-K3Kx99tM.js.map
